
import WarpcastButton from '../components/WarpcastButton';

export default function HomePage() {
  return (
    <div>
      <h1>Warpcast News Portal</h1>

      {/* Komponen Warpcast */}
      <WarpcastButton />
    </div>
  );
}
